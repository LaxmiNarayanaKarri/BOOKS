<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />
	<title>ABOUT US</title>
	 <link rel='icon' href="img1.jpg"/>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<style type="text/css">
		.i
		{
			position:absolute;
			width:1350px;
			height:2200px;
			background-repeat:repeat;
		}
		body
		{
			background-image:url('bg.gif');
			width:50%;
			overflow-x:hidden;
			overflow-y:scroll;
			background-size:cover;
			background-position: center;
			background-repeat: no-repeat;
    		background-attachment: fixed;
		}
		
		.about h1
		{
			align-content:center;
			position:relative;
			margin-left:-150px;
			height:500px;
			width:450px;
			text-align:center;
			background-color: rgba(255,255,255,0.7);
		}
		.hea
		{
			color:black;
			position: relative;
			top:15px;
			left:550px;
			
		}
		span
		{
			animation: text 3s ease forwards infinite;
		}
		.huh
		{
			color:black;
			position: relative;
			top:95px;
			left:550px;
		}
		.what
		{
			color:black;
			position: relative;
			top:175px;
			left:550px;
		}
		.so
		{
			color:black;
			position: relative;
			top:255px;
			left:550px;
		}
		.link
		{
			height:250px;
			position: relative;
			top:285px;
			width:1350px;
			z-index:1;
			background-color: black;
		}
		.lh
		{
			color: white;

		}
		.contact
		{
			position: relative;
			top:285px;
			height:350px;
			width:1350px;
			background-color:black;
			color:white;
			z-index:1;
		}
		li,h2
		{
			margin-left:550px;
		}
		.dropdown
		{
			text-decoration:none;
			color:white;
			font-size:20px;
		}
		a
		{
			position: relative;
			z-index: 5;
		}
		@keyframes text
		{
			0%{color:black;
				}
			50%{
				text-align:center;
				color:yellow;
				letter-spacing:8px;
				text-shadow:3px 8px 8px black;
				}
			75%
			{
				color:brown;
			}
			100%
			{
				color:black;
				letter-spacing:1px;
			}
		}
	
		.line
		{
			position: relative;
			width:1350px;
			top:285px;
			height:1px;
			background-color: white;
			color:white;
		}
		.con1,.p1,.f1
		{
			margin-left:25px;
		}
		.p1
		{
			font-size:20px;
			font-weight:600;
		}
		#l1,#l2,#l3
		{
			position:relative;
			padding-left:35px;
			font-size:60px;
			z-index:5;
		}
		.final
		{
			font-size:20px;
			margin-top:20px;
			margin-left:30px;
		}
		.a2
		{
			color: #E1306C;
		}
		.a3
		{
			color:red;
		}
		.wha
		{
			position:relative;
			top:10px;
			font-size:20px;
		}
		.pw
		{
			top:25px;
			font-size:30px;
			position: relative;
			left:65px;
			text-align:left;
		}
		p
		{
			position: relative;
			left:9px;
			display: block;
			font-size:33px;
			text-align:left;

		}
	</style>
</head>

<body>
<div class="con">
	<img src="but.gif" class="i">
</div>
<div class="about">
	<h1 class="hea"><span>ABOUT</span>
	<p>Hi There.It's the pleasure work of Mr.LaxmiNarayana striving to be the best coder even anyone can't imagine to be.</p>
	<p>He is currently pursuing his btech 3rd year(cse) at NIT MANIPUR.</p>
	<p>	Special Thanks to My Friends Sudheer,Sreeram,Pavan.</p>
</h1>
</div>
<div class="about">
	<h1 class="huh"><span>GOAL</span>

		<p>
			<br>
			This is the place where you can
			find books for free or at partial
			price.Everything is useful in one
			or other way,so let's make the 
			right use of books.
		</p>
	</h1>
</div>
<div class="about">
	<h1 class="what"><span>WHAT</span>
		<br>
	<p class="wha">SOME WEB TECH I LIKE TO USE IS:</p>
	<p class="pw">	.HMTL</p>
	<p class="pw">	.JS</p>
	<p class="pw">	.CSS</p>
	<p class="pw">	.MYSQL</p>
	<p class="pw">	.PHP</p>
	<p class="pw">.BOOTSTRAP</p>
	<p class="pw">	.FONTAWESOME</p>
</h1>
</div>
<div class="about">
	<h1 class="so"><span>HOW</span>
	<p>
		<br>
		.First of all get yourself registered
		 with email verification
		 <br>
		.Next,Login with your credentials
		<br>
		.Then after you can buy or sell a
		 book.It's that simple,Make use of
		 it in a right way.
	</p>
	</h1>
</div>
<div class="link">
	<br>
	<h2 class="lh">LINKS</h2>
	<br>
	<ul class="dropdown" >
    		<li><a class="dropdown" href="home">HOME</a></li>
   			<li><a class="dropdown" href="login">LOGIN</a></li>
    		<li><a class="dropdown" href="register">REGISTER</a></li>
    </ul>
</div>
<div class="line">
	
</div>
<div class="contact">
	<h1 class="con1">Contact Us</h1>
	<p class="p1">PHONE: 9966543083</p>
	<p class="p1">EMAIL: klnarayana6321@gmail.com</p>
	<br>
	<h1 class="f1">Follow</h1>
	<a href="https://www.facebook.com/laxminarayana.karri"><i class="fab fa-facebook-f" id="l1"></i></a>
	<a href="https://www.instagram.com/johnwick_6/?utm_medium=copy_link" class="a2"><i class="fab fa-instagram" id="l2"></i></a>
	<a href="https://www.youtube.com/channel/UCocIITOevYWe1CcnVXwFj0g" class="a3"><i class="fab fa-youtube" id="l3"></i></a>
	<br>
	<p class="final"><i class="far fa-copyright"></i> All Rights Reserved</p>

</div>
<script src="https://kit.fontawesome.com/5283fdf09a.js" crossorigin="anonymous"></script>
</body>
</html>